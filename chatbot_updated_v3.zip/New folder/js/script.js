document.getElementById('current-year').textContent = new Date().getFullYear();

document.addEventListener('DOMContentLoaded', () => {
    const chatToggle = document.getElementById('chat-toggle');
    const chatWindow = document.getElementById('chat-window');
    const chatClose = document.getElementById('chat-close');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const chatMessages = document.getElementById('chat-messages');
    const questionChips = document.querySelectorAll('.question-chip');
    const submitTicketBtn = document.getElementById('submit-ticket-btn');
    const ticketModal = document.getElementById('ticket-modal');
    const ticketModalClose = document.getElementById('ticket-modal-close');
    const ticketForm = document.getElementById('ticket-form');

    let chatOpen = false;

    const replies = [
        {
            match: ['nursing', 'nurse'],
            text: 'To apply for nursing roles, you would usually need relevant qualifications, registration requirements and an application through NHS Scotland Jobs. I can also help with entry routes, specialisms and salary information.'
        },
        {
            match: ['qualification', 'qualifications', 'requirements'],
            text: 'Entry requirements vary by role, but many healthcare careers ask for specific qualifications, relevant experience and right-to-work checks. Tell me the role you want and I can guide you further.'
        },
        {
            match: ['salary', 'band 5', 'pay'],
            text: 'Band 5 roles are commonly used for newly qualified professional posts. Salary depends on the role and current pay banding, but I can help explain the difference between bands and progression routes.'
        },
        {
            match: ['apprenticeship', 'apprenticeships'],
            text: 'Apprenticeships can be a good route into NHS Scotland careers. They combine practical work with structured learning and may be available in clinical, business and support roles.'
        }
    ];

    function announceStatus(message) {
        const announcer = document.getElementById('aria-announcer') || document.createElement('div');
        announcer.id = 'aria-announcer';
        announcer.setAttribute('aria-live', 'polite');
        announcer.setAttribute('aria-atomic', 'true');
        announcer.className = 'visually-hidden';
        announcer.textContent = message;
        document.body.appendChild(announcer);
        setTimeout(() => {
            announcer.textContent = '';
        }, 1000);
    }

    function toggleChat() {
        chatOpen = !chatOpen;
        chatToggle.setAttribute('aria-expanded', String(chatOpen));

        if (chatOpen) {
            chatWindow.classList.add('visible');
            userInput.focus();
            announceStatus('Chat assistant is open.');
        } else {
            chatWindow.classList.remove('visible');
            chatToggle.focus();
            announceStatus('Chat assistant is closed.');
        }
    }

    function closeChat() {
        if (!chatOpen) return;
        chatOpen = false;
        chatToggle.setAttribute('aria-expanded', 'false');
        chatWindow.classList.remove('visible');
        chatToggle.focus();
        announceStatus('Chat assistant is closed.');
    }

    function formatTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    function addMessage(text, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'} new-message`;
        messageDiv.innerHTML = `<p>${text}</p><div class="message-time">${formatTime()}</div>`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        setTimeout(() => messageDiv.classList.remove('new-message'), 300);
    }

    function getReply(text) {
        const lowerText = text.toLowerCase();
        const found = replies.find(reply => reply.match.some(keyword => lowerText.includes(keyword)));

        if (found) return found.text;

        return 'Thank you for your question. I can help with NHS Scotland careers, applications, qualifications, salaries and training pathways. Please tell me which role or topic you want to explore.';
    }

    function handleSend(prefilledText = '') {
        const text = (prefilledText || userInput.value).trim();
        if (!text) return;

        addMessage(text, true);
        userInput.value = '';

        setTimeout(() => {
            addMessage(getReply(text), false);
        }, 500);
    }

    function openModal() {
        ticketModal.classList.add('visible');
        ticketModal.setAttribute('aria-hidden', 'false');
        document.getElementById('ticket-name').focus();
    }

    function closeModal() {
        ticketModal.classList.remove('visible');
        ticketModal.setAttribute('aria-hidden', 'true');
        submitTicketBtn.focus();
    }

    chatToggle.addEventListener('click', toggleChat);
    chatClose.addEventListener('click', closeChat);
    sendBtn.addEventListener('click', () => handleSend());
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSend();
    });

    questionChips.forEach(chip => {
        chip.addEventListener('click', () => {
            if (!chatOpen) {
                chatOpen = true;
                chatToggle.setAttribute('aria-expanded', 'true');
                chatWindow.classList.add('visible');
            }
            handleSend(chip.textContent);
        });
    });

    submitTicketBtn.addEventListener('click', openModal);
    ticketModalClose.addEventListener('click', closeModal);

    ticketForm.addEventListener('submit', (e) => {
        e.preventDefault();
        closeModal();
        if (!chatOpen) {
            chatOpen = true;
            chatToggle.setAttribute('aria-expanded', 'true');
            chatWindow.classList.add('visible');
        }
        addMessage('Your support ticket has been submitted successfully. A member of the team will review your details shortly.', false);
        ticketForm.reset();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (ticketModal.classList.contains('visible')) {
                closeModal();
            } else if (chatOpen) {
                closeChat();
            }
        }
    });

    document.addEventListener('click', (e) => {
        if (chatOpen && !chatWindow.contains(e.target) && !chatToggle.contains(e.target) && !ticketModal.contains(e.target)) {
            closeChat();
        }

        if (e.target === ticketModal) {
            closeModal();
        }
    });

    setTimeout(() => {
        announceStatus('Page loaded. Use the chat button to open the assistant.');
    }, 1000);
});
